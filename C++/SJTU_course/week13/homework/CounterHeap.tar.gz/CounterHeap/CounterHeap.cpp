#include "CounterHeap.h"

CounterHeap::CounterHeap(double percent)
{
    // you code here
}

CounterHeap::CounterHeap(double percent, vector<int> init_elements)
{
    // you code here
}

CounterHeap::~CounterHeap()
{
    // you code here
}

int CounterHeap::getBreakPoint()
{
    return ceil((minHeap.size() + maxHeap.size()) * percentage);
}

void CounterHeap::insert(int element)
{
    // you code here
}

void CounterHeap::insert(vector<int> new_elements)
{
    // you code here
}

bool CounterHeap::erase(int val)
{
    // you code here
}

int CounterHeap::target()
{
    // you code here
}

int CounterHeap::size()
{
    // you code here
}